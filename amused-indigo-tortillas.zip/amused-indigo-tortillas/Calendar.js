import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import { Calendar } from 'react-native-calendars';

const consultations = [
  { id: '1', doctor: 'Tania Quintella', specialty: 'Pneumologista', time: '09:00', date: '2023-10-15' },
  { id: '2', doctor: 'Catarina de Paula', specialty: 'Clínico geral', time: '15:30', date: '2023-10-15' },
  // Adicione mais consultas aqui
];

const history = [
  { id: '1', doctor: 'João Silva', specialty: 'Cardiologista', time: '11:00', date: '2023-09-10' },
  { id: '2', doctor: 'Maria Oliveira', specialty: 'Dermatologista', time: '12:00', date: '2023-08-05' },
  // Adicione mais histórico aqui
];

export default function CalendarScreen({ navigation }) {
  const [viewMode, setViewMode] = useState('calendar'); // Alterna entre 'calendar' e 'list'
  const [tab, setTab] = useState('upcoming'); // Alterna entre 'upcoming' e 'history'
  const [selectedDate, setSelectedDate] = useState('2023-10-15');

  const renderConsultations = (data) => {
    return data
      .filter(consultation => consultation.date === selectedDate)
      .map(consultation => (
        <View key={consultation.id} style={styles.consultationCard}>
          <Text style={styles.doctorName}>{consultation.doctor}</Text>
          <Text style={styles.specialty}>{consultation.specialty}</Text>
          <Text style={styles.time}>{consultation.time}</Text>
          <View style={styles.buttons}>
            <TouchableOpacity style={styles.cancelButton}>
              <Text style={styles.buttonText}>Cancelar</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.rescheduleButton}>
              <Text style={styles.buttonText}>Regendar</Text>
            </TouchableOpacity>
          </View>
        </View>
      ));
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.scrollContent}>
      <View style={styles.header}>
        <Text style={styles.title}>Consultas</Text>
        <View style={styles.icons}>
          <FontAwesome 
            name="calendar" 
            size={24} 
            color={viewMode === 'calendar' ? 'green' : 'gray'} 
            onPress={() => setViewMode('calendar')} 
          />
          <FontAwesome 
            name="list" 
            size={24} 
            color={viewMode === 'list' ? 'green' : 'gray'} 
            onPress={() => setViewMode('list')} 
          />
        </View>
      </View>
      <View style={styles.tabs}>
        <TouchableOpacity
          style={[styles.tabButton, tab === 'upcoming' && styles.activeTab]}
          onPress={() => setTab('upcoming')}
        >
          <Text style={styles.tabText}>Em breve</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tabButton, tab === 'history' && styles.activeTab]}
          onPress={() => setTab('history')}
        >
          <Text style={styles.tabText}>Historico</Text>
        </TouchableOpacity>
      </View>
      {viewMode === 'calendar' ? (
        <Calendar
          onDayPress={(day) => setSelectedDate(day.dateString)}
          markedDates={{
            [selectedDate]: { selected: true, selectedColor: 'green' },
          }}
          theme={{
            selectedDayBackgroundColor: 'green',
            todayTextColor: 'green',
          }}
        />
      ) : (
        <View style={styles.listContainer}>
          {renderConsultations(tab === 'upcoming' ? consultations : history)}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f5',
    padding: 20,
  },
  scrollContent: {
    paddingBottom: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  icons: {
    flexDirection: 'row',
  },
  tabs: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  tabButton: {
    flex: 1,
    padding: 10,
    alignItems: 'center',
    borderBottomWidth: 2,
    borderColor: 'transparent',
  },
  activeTab: {
    borderColor: 'green',
  },
  tabText: {
    fontSize: 16,
  },
  listContainer: {
    paddingBottom: 20,
  },
  consultationCard: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  doctorName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  specialty: {
    fontSize: 16,
    color: '#666',
    marginBottom: 10,
  },
  time: {
    fontSize: 16,
    marginBottom: 15,
  },
  buttons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  cancelButton: {
    backgroundColor: '#ff6347',
    padding: 10,
    borderRadius: 5,
  },
  rescheduleButton: {
    backgroundColor: '#32cd32',
    padding: 10,
    borderRadius: 5,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
  },
});