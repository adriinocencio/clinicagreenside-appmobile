import React from 'react';
import { View, Text, Image, StyleSheet, FlatList, ScrollView } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';

const ProfileScreen = ({ navigation }) => {
  const allergies = [
    { id: '1', name: 'Pólen' },
    { id: '2', name: 'Amendoim' },
    { id: '3', name: 'Penicilina' },
    // Adicione mais alergias aqui
  ];

  const medications = [
    { id: '1', name: 'Ibuprofeno' },
    { id: '2', name: 'Metformina' },
    // Adicione mais medicamentos aqui
  ];

  const medicalHistory = [
    { id: '1', date: '01/01/2023', description: 'Consulta de rotina' },
    { id: '2', date: '15/03/2023', description: 'Tratamento de bronquite' },
    // Adicione mais registros de histórico médico aqui
  ];

  const renderListItem = ({ item }) => (
    <View style={styles.listItem}>
      <Text>{item.name || item.description}</Text>
      {item.date && <Text style={styles.listItemDate}>{item.date}</Text>}
    </View>
  );

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.scrollContent}>
      <View style={styles.header}>
        <Image source={{ uri: 'https://via.placeholder.com/100' }} style={styles.profileImage} />
        <Text style={styles.name}>Ana Camargo Drumond</Text>
        <Text style={styles.infoLabel}>CPF</Text>
        <Text style={styles.info}>737.835.678-66</Text>
        <Text style={styles.infoLabel}>Email</Text>
        <Text style={styles.info}>anacamargo@gmail.com</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Alergias</Text>
        <FlatList
          data={allergies}
          renderItem={renderListItem}
          keyExtractor={item => item.id}
          scrollEnabled={false}
        />
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Medicamentos</Text>
        <FlatList
          data={medications}
          renderItem={renderListItem}
          keyExtractor={item => item.id}
          scrollEnabled={false}
        />
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Histórico Médico</Text>
        <FlatList
          data={medicalHistory}
          renderItem={renderListItem}
          keyExtractor={item => item.id}
          scrollEnabled={false}
        />
      </View>

      <View style={styles.footer}>
        <FontAwesome name="home" size={24} color="green" onPress={() => navigation.navigate('Home')} />
        <FontAwesome name="calendar" size={24} color="green" onPress={() => navigation.navigate('Calendar')} />
        <FontAwesome name="comments" size={24} color="green" onPress={() => navigation.navigate('Messages')} />
        <FontAwesome name="user" size={24} color="green" onPress={() => navigation.navigate('Profile')} />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f5',
    padding: 20,
  },
  scrollContent: {
    paddingBottom: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 20,
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 10,
  },
  name: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 5,
  },
  infoLabel: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  info: {
    fontSize: 16,
    marginBottom: 10,
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  listItem: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  listItemDate: {
    fontSize: 12,
    color: '#666',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    height: 50,
    borderTopWidth: 1,
    borderColor: '#e0e0e0',
  },
});

export default ProfileScreen;