import React from 'react';
import { View, Text, Image, TextInput, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { FontAwesome } from '@expo/vector-icons';

const HomeScreen = ({ navigation }) => {
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.scrollContent}>
      <View style={styles.header}>
        <Image source={{ uri: 'https://via.placeholder.com/100' }} style={styles.profileImage} />
        <Text style={styles.greeting}>Olá, Ana</Text>
      </View>
      <TextInput
        style={styles.searchInput}
        placeholder="Procurar..."
      />
      <View style={styles.nextAppointment}>
        <Text style={styles.nextAppointmentText}>Próxima consulta</Text>
        <Text style={styles.appointmentDate}>15/10/2023</Text>
        <Text style={styles.appointmentTime}>09:00</Text>
      </View>
      <Image source={{ uri: 'https://via.placeholder.com/300x150' }} style={styles.adImage} />
      <View style={styles.servicesSection}>
        <Text style={styles.sectionTitle}>Explorar Serviços</Text>
        <View style={styles.services}>
          <TouchableOpacity style={styles.serviceButton}>
            <FontAwesome name="stethoscope" size={24} color="green" />
            <Text>Consultas</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.serviceButton}>
            <FontAwesome name="medkit" size={24} color="green" />
            <Text>Vacinação</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.serviceButton}>
            <FontAwesome name="ambulance" size={24} color="green" />
            <Text>Emergência</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.serviceButton}>
            <FontAwesome name="plus-square" size={24} color="green" />
            <Text>Medicamentos</Text>
          </TouchableOpacity>
        </View>
      </View>
      <View style={styles.articlesSection}>
        <Text style={styles.sectionTitle}>Explorar Artigos</Text>
        <View style={styles.article}>
          <Text style={styles.articleTitle}>Dicas para uma Dieta Equilibrada</Text>
          <Text style={styles.articleAuthor}>João Castillo</Text>
          <Text style={styles.articleSnippet}>Desde dicas para refeições rápidas até opções de lanche saudáveis...</Text>
        </View>
      </View>
      <View style={styles.footer}>
        <FontAwesome name="home" size={24} color="green" onPress={() => navigation.navigate('Home')} />
        <FontAwesome name="calendar" size={24} color="green" onPress={() => navigation.navigate('Calendar')} />
        <FontAwesome name="comments" size={24} color="green" onPress={() => navigation.navigate('Messages')} />
        <FontAwesome name="user" size={24} color="green" onPress={() => navigation.navigate('Profile')} />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f5',
    padding: 20,
  },
  scrollContent: {
    paddingBottom: 20,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  profileImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 10,
  },
  greeting: {
    fontSize: 22,
    fontWeight: 'bold',
  },
  searchInput: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    paddingHorizontal: 8,
    marginBottom: 20,
  },
  nextAppointment: {
    backgroundColor: '#00b33c',
    padding: 20,
    borderRadius: 10,
    marginBottom: 20,
  },
  nextAppointmentText: {
    color: '#fff',
    fontSize: 18,
    marginBottom: 10,
  },
  appointmentDate: {
    color: '#fff',
    fontSize: 16,
  },
  appointmentTime: {
    color: '#fff',
    fontSize: 16,
  },
  adImage: {
    width: '100%',
    height: 150,
    borderRadius: 10,
    marginBottom: 20,
  },
  servicesSection: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  services: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  serviceButton: {
    alignItems: 'center',
  },
  articlesSection: {
    marginBottom: 20,
  },
  article: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 3,
  },
  articleTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  articleAuthor: {
    fontSize: 16,
    color: '#666',
    marginBottom: 5,
  },
  articleSnippet: {
    fontSize: 14,
    color: '#333',
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    height: 50,
    borderTopWidth: 1,
    borderColor: '#e0e0e0',
  },
});

export default HomeScreen;